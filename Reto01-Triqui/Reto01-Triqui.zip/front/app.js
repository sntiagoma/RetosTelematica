var app = {}
app.name = "WebImage";
module.exports = app;