var TrikiSigns = {
    X:"X",
    O:"O"
};

module.exports = TrikiSigns;